package gameObjects;
import move.*;

import java.awt.Graphics;
import java.awt.Color;

/**
 * Food Object for Snake Game Project
 * Child of Logic Class
 * @author Austin Levesque
 * @author Chris O'Reilly
 * @author Steven Canon-Almagro
 * @author Victor Chu
 * @author Navjot Saran
 */
public class Food extends Logic {

	/**
	 * Default Constructor
	 * @param foodTopLeft
	 * @param foodSize
	 */
	public Food(Point foodTopLeft, int foodSize) {
		super(foodTopLeft, foodSize);
	}

	/**
	 * Draw Method for GUI
	 */
	public void draw(Graphics g){
		g.setColor(Color.RED);
		g.fillOval(getTopLeft().getXCoord(), getTopLeft().getYCoord(),getSize() * 2,getSize() * 2);
	}
}
