package gameObjects;
import move.Point;

import java.awt.*;
import java.util.Random;

public abstract class Logic {

  Point topLeft = new Point(0,0);
  int size;
  public int score = 0;
  public String direction = "down";
  int r1;
  int r2;
  boolean checkFood = false;

  public Logic(Point snakeTopLeft, int snakeSize) {
		topLeft = snakeTopLeft;
		size = snakeSize;
	}
  public boolean foodBoolean(String snakeLoc, String foodLoc) {
	  if (snakeLoc.equals(foodLoc)) {
		  return true;
  	  }
	  else {
		  return false;
  	  }
  } 

  public Point getTopLeft() {
    return topLeft;
  }

  public int getSize() {
    return size;
  }

  public void moveDir(int amount) {
    if (direction == "down"){
      topLeft.moveDown(amount);
    }else if (direction == "up") {
      topLeft.moveUp(amount);
    }else if (direction == "left"){
      topLeft.moveLeft(amount);
    } else {
      topLeft.moveRight(amount);
    }
  }

  public Point newLoc(int range) {
    Random rand1 = new Random();
    Point newPoint = new Point(0,0);
    if(range == 26) {
      r1 = rand1.nextInt(26) * 30 + 8;
      r2 = rand1.nextInt(26) * 30;
      newPoint.setXCoord(r1);
      newPoint.setYCoord(r2);
    }
    else if (range == 10) {
      r1 = rand1.nextInt(9) + 1;
      r2 = rand1.nextInt(9) + 1;
      newPoint.setXCoord1(r1);
      newPoint.setYCoord1(r2);
    }
    System.out.println(getLoc(newPoint));
    return newPoint;
  }

  public String getLoc(Point pointToCheck) {
    String loc = ("("+pointToCheck.getXCoord()+","+pointToCheck.getYCoord()+")");
    return loc;
  }

  public abstract void draw(Graphics g);

}
