package gameObjects;
import move.*;

import java.awt.Graphics;
import java.util.ArrayList;
import java.awt.Color;

public class Snake extends Logic {

	public ArrayList<Point> tail = new ArrayList<Point>();
	public ArrayList<Snake> tailSnakes = new ArrayList<Snake>();
	public ArrayList<String> tailStrings = new ArrayList<String>();
	//can't think of a better way to use the contains() method than with a string list

	public Snake(Point snakeTopLeft, int snakeSize) {
		super(snakeTopLeft, snakeSize);
	}

	public void draw(Graphics g){
		g.setColor(Color.GREEN);
		g.fillRect(getTopLeft().getXCoord(), getTopLeft().getYCoord(),getSize() * 2,getSize() * 2);
	}
	
	public void updateTail(int prevPtX,int prevPtY){
		Point prevPt = new Point(prevPtX,prevPtY);
	    tail.add(prevPt);
	    tailStrings.add(getLoc(prevPt));
	    Snake tempTail = new Snake(prevPt, 15);
	    tailSnakes.add(tempTail);
	    if ((tail.size()) > score) {
	      while((tail.size()) > score){
	        tail.remove(0);
	        tailSnakes.remove(0);
	        tailStrings.remove(0);
	      }
	    }
	}
}
