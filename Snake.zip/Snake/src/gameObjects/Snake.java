package gameObjects;
import move.*;

import java.awt.Graphics;
import java.util.ArrayList;
import java.awt.Color;
	
/**
 * Snake Object for Snake Game Project
 * Child of Logic Class
 * @author Austin Levesque
 * @author Chris O'Reilly
 * @author Steven Canon-Almagro
 * @author Victor Chu
 * @author Navjot Saran
 */
public class Snake extends Logic {

	private ArrayList<Point> tail = new ArrayList<Point>();
	private ArrayList<Snake> tailSnakes = new ArrayList<Snake>();
	private ArrayList<String> tailStrings = new ArrayList<String>();
	//can't think of a better way to use the contains() method than with a string list

	/**
	 * Default Constructor
	 * @param snakeTopLeft
	 * @param snakeSize
	 */
	public Snake(Point snakeTopLeft, int snakeSize) {
		super(snakeTopLeft, snakeSize);
	}

	/**
	 * Updates Tail lists with the previous points/coordinates of the head
	 * Deletes the oldest value in the lists based on the size of the tail i.e. the score
	 * @param prevPtX
	 * @param prevPtY
	 */
	public void updateTail(int prevPtX,int prevPtY){
		Point prevPt = new Point(prevPtX,prevPtY);
	    tail.add(prevPt);
	    tailStrings.add(getLoc(prevPt));
	    Snake tempTail = new Snake(prevPt, 15);
	    tailSnakes.add(tempTail);
	    if ((tail.size()) > getScore()) {
	    	while((tail.size()) > getScore()){
	    		tail.remove(0);
	    		tailSnakes.remove(0);
	    		tailStrings.remove(0);
	    	}
	    }
	}
	
	public ArrayList<Point> getTail() {
		return tail;
	}
	
	public ArrayList<Snake> getTailSnakes() {
		return tailSnakes;
	}
	
	public ArrayList<String> getTailStrings() {
		return tailStrings;
	}
	
	/**
	 * Draw Method for GUI
	 */
	public void draw(Graphics g){
		g.setColor(Color.GREEN);
		g.fillRect(getTopLeft().getXCoord(), getTopLeft().getYCoord(),getSize() * 2,getSize() * 2);
	}
}
