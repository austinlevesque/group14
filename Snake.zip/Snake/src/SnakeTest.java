import static org.junit.Assert.*;

import gameObjects.*;
import move.*;
import org.junit.*;

public class SnakeTest {

	@Test
	public void test_setXCoord_ValueLargerThanMax() {
		Point p = new Point(2000, 200);
		p.setXCoord(2000);
		assertEquals("X-Coordinate should be set to minimum value", 8, p.getXCoord());
	}

	@Test
	public void test_setXCoord_ValueSmallerThanMin() {
		Point p = new Point(0, 200);
		p.setXCoord(0);
		assertEquals("X-Coordinate should be set to minimum value", 788, p.getXCoord());
	}
	
	@Test
	public void test_setYCoord_ValueLargerThanMax() {
		Point p = new Point(200, 2000);
		p.setYCoord(2000);
		assertEquals("X-Coordinate should be set to minimum value", 30, p.getYCoord());
	}
	
	@Test
	public void test_setYCoord_ValueSmallerThanMin() {
		Point p = new Point(200, 0);
		p.setYCoord(0);
		assertEquals("X-Coordinate should be set to minimum value", 780, p.getYCoord());
	}

	
	@Test
	public void test_foodBoolean_FoodLocationIsSnakeLocation() {
		Food l = new Food(new Point(0,0), 15);
		assertTrue("Strings are equal.  Method should return true", l.foodBoolean("", ""));
	}
	
	@Test
	public void test_foodBoolean_FoodLocationIsNotSnakeLocation() {
		Food l = new Food(new Point(0,0), 15);
		assertFalse("Strings are not equal.  Method should return false", l.foodBoolean("it's", "different"));
	}
	
	@Test
	public void test_newLoc_PointIsDifferent() {
		Food l = new Food(new Point(0,0), 15);
		assertNotSame("A new point should have been generated when newLoc was called.", l.newLoc(26), l.newLoc(26));
	}
	
}
